/*
  MCP2515 CAN Controller Library for Arduino
  
  MIT License
  https://github.com/codeljo/AA_MCP2515
*/

#ifndef _AA_MCP2515_H
#define _AA_MCP2515_H

#include "CANController.h"

#endif  /* _AA_MCP2515_H */
